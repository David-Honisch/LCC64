{keyboardListeningElement: div#c64TextInputReceiver, hasFocus: false, startSequence: 0, error: �, preRun: Array(1), �}
ALLOC_DYNAMIC: 3
ALLOC_NONE: 4
ALLOC_NORMAL: 0
ALLOC_STACK: 1
ALLOC_STATIC: 2
AsciiToString: � AsciiToString(ptr)
FS_createDataFile: � (parent,name,data,canRead,canWrite,canOwn)
FS_createDevice: � (parent,name,input,output)
FS_createFolder: � (parent,name,canRead,canWrite)
FS_createLazyFile: � (parent,name,url,canRead,canWrite)
FS_createLink: � (parent,name,target,canRead,canWrite)
FS_createPath: � (parent,path,canRead,canWrite)
FS_createPreloadedFile: � (parent,name,url,canRead,canWrite,onload,onerror,dontCreateFile,canOwn,preFinish)
FS_unlink: � (path)
HEAP: undefined
HEAP8: Int8Array(16777216) [101, 109, 115, 99, 0, 0, 0, 0, 56, 102, 0, 0, 0, -119, 0, 0, 24, 0, 0, 0, 0, 0, 0, 0, 16, 102, 0, 0, 14, -119, 0, 0, 56, 102, 0, 0, -109, -114, 0, 0, -120, 0, 0, 0, 0, 0, 0, 0, 56, 102, 0, 0, 37, -114, 0, 0, 64, 0, 0, 0, 0, 0, 0, 0, 16, 102, 0, 0, 51, -114, 0, 0, 56, 102, 0, 0, 87, -114, 0, 0, 96, 0, 0, 0, 0, 0, 0, 0, 16, 102, 0, 0, 72, -114, 0, 0, 116, 102, 0, 0, �]
HEAP16: Int16Array(8388608) [28005, 25459, 0, 0, 26168, 0, -30464, 0, 24, 0, 0, 0, 26128, 0, -30450, 0, 26168, 0, -29037, 0, 136, 0, 0, 0, 26168, 0, -29147, 0, 64, 0, 0, 0, 26128, 0, -29133, 0, 26168, 0, -29097, 0, 96, 0, 0, 0, 26128, 0, -29112, 0, 26228, 0, -29086, 0, 0, 0, 3, 0, 88, 0, 2, 0, 136, 0, 4098, 0, 144, 0, 5122, 0, 26128, 0, -29054, 0, 26128, 0, -29071, 0, 26168, 0, -27436, 0, 168, 0, 0, 0, 26228, 0, -27412, 0, 0, 0, 2, 0, 24, 0, 2, 0, 200, 0, 1026, 0, �]
HEAP32: Int32Array(4194304) [1668509029, 0, 26168, 35072, 24, 0, 26128, 35086, 26168, 36499, 136, 0, 26168, 36389, 64, 0, 26128, 36403, 26168, 36439, 96, 0, 26128, 36424, 26228, 36450, 0, 3, 88, 2, 136, 4098, 144, 5122, 26128, 36482, 26128, 36465, 26168, 38100, 168, 0, 26228, 38124, 0, 2, 24, 2, 200, 1026, 26128, 38143, 26168, 38364, 224, 0, 26128, 38373, 26168, 75252, 248, 0, 26128, 75277, 26168, 75296, 232, 0, 26168, 75318, 256, 0, 26168, 75346, 256, 0, 26168, 75371, 256, 0, 26168, 75406, 256, 0, 26168, 75436, 232, 0, 26168, 75459, 232, 0, 26168, 75527, 232, 0, 26128, 75515, 26168, 75548, �]
HEAPF32: Float32Array(4194304) [4.490441516634203e+21, 0, 3.6669178214451813e-41, 4.914633974079998e-41, 3.363116314379561e-44, 0, 3.661312627587882e-41, 4.916595791930053e-41, 3.6669178214451813e-41, 5.11459926493915e-41, 1.9057659114817512e-43, 0, 3.6669178214451813e-41, 5.099184981831577e-41, 8.96831017167883e-44, 0, 3.661312627587882e-41, 5.101146799681632e-41, 3.6669178214451813e-41, 5.106191474153201e-41, 1.3452465257518244e-43, 0, 3.661312627587882e-41, 5.104089526456714e-41, 3.67532561223113e-41, 5.107732902463958e-41, 0, 4.203895392974451e-45, 1.233142648605839e-43, 2.802596928649634e-45, 1.9057659114817512e-43, 5.7425211068031e-42, 2.0178697886277366e-43, 7.177450734271713e-42, 3.661312627587882e-41, 5.112217057549798e-41, 3.661312627587882e-41, 5.109834850160445e-41, 3.6669178214451813e-41, 5.338947149077553e-41, 2.3541814200656927e-43, 0, 3.67532561223113e-41, 5.342310265391933e-41, 0, 2.802596928649634e-45, 3.363116314379561e-44, 2.802596928649634e-45, 2.802596928649634e-43, 1.4377322243972623e-42, 3.661312627587882e-41, 5.34497273247415e-41, 3.6669178214451813e-41, 5.375941428535728e-41, 3.1389085600875902e-43, 0, 3.661312627587882e-41, 5.377202597153621e-41, 3.6669178214451813e-41, 1.0545051203737113e-40, 3.4752201915255463e-43, 0, 3.661312627587882e-41, 1.0548554449897925e-40, 3.6669178214451813e-41, 1.0551216916980143e-40, 3.2510124372335756e-43, 0, 3.6669178214451813e-41, 1.0554299773601657e-40, 3.587324068671532e-43, 0, 3.6669178214451813e-41, 1.0558223409301767e-40, 3.587324068671532e-43, 0, 3.6669178214451813e-41, 1.0561726655462579e-40, 3.587324068671532e-43, 0, 3.6669178214451813e-41, 1.0566631200087716e-40, 3.587324068671532e-43, 0, 3.6669178214451813e-41, 1.057083509548069e-40, 3.2510124372335756e-43, 0, 3.6669178214451813e-41, 1.0574058081948637e-40, 3.2510124372335756e-43, 0, 3.6669178214451813e-41, 1.0583586911506046e-40, 3.2510124372335756e-43, 0, 3.661312627587882e-41, 1.0581905353348856e-40, 3.6669178214451813e-41, 1.0586529638281128e-40, �]
HEAPF64: Float64Array(2097152) [8.24352991e-315, 7.44226363936627e-310, 1.2e-322, 7.44523443347165e-310, 7.745072438737e-310, 6.7e-322, 7.7217304850364e-310, 3.16e-322, 7.7247012791418e-310, 7.73234046399123e-310, 4.74e-322, 7.7291574703028e-310, 7.73467465936425e-310, 6.365987373e-314, 4.2439916254e-314, 8.695938751443e-311, 1.08688624413953e-310, 7.7414650458904e-310, 7.73785765304576e-310, 8.08480396487056e-310, 8.3e-322, 8.08989675477184e-310, 4.243991582e-314, 4.243991594e-314, 2.177167681629e-311, 8.09392854676973e-310, 8.14082465375204e-310, 1.107e-321, 8.14273444996193e-310, 1.596844272746474e-309, 1.225e-321, 1.597374771694018e-309, 1.5977779508945e-309, 1.146e-321, 1.59824478996851e-309, 1.265e-321, 1.59883894878998e-309, 1.265e-321, 1.599369447737722e-309, 1.265e-321, 1.60011214626456e-309, 1.265e-321, 1.60074874500185e-309, 1.146e-321, 1.60123680403377e-309, 1.146e-321, 1.60267976117163e-309, 1.146e-321, 1.602425121676515e-309, 1.60312538028773e-309, 1.146e-321, 1.603570999403834e-309, 9.9e-322, 1.61469025734849e-309, 2.174e-321, 1.61500855671694e-309, 1.62347531992309e-309, 2.29e-321, 1.623199460470065e-309, 1.624175578534107e-309, 2.213e-321, 1.62527901634541e-309, 2.49e-321, 1.625597315713856e-309, 1.62593683504061e-309, 2.41e-321, 1.626233914451343e-309, 2.41e-321, 1.630308146369996e-309, 1.2e-322, 1.646371654507603e-309, 2.846e-321, 1.64677483370769e-309, 1.658424590600286e-309, 2.767e-321, 1.66118318512854e-309, 6.7e-322, 1.661628804244644e-309, 4.35e-322, 1.662711022098036e-309, 2.174e-321, 1.66886480989164e-309, 1.66909822942884e-309, 3.2e-321, 1.677395232971516e-309, 7.1e-322, 1.67947478884666e-309, 4.35e-322, 1.68452513882916e-309, 1.2e-322, 1.68520417748227e-309, 3.636e-321, 1.68569223651399e-309, 1.686095415714276e-309, 1.68738983314696e-309, 3.794e-321, 1.6876869125575e-309, 1.68798399196843e-309, 3.794e-321, 1.84155282736039e-309, �]
HEAPU8: Uint8Array(16777216) [101, 109, 115, 99, 0, 0, 0, 0, 56, 102, 0, 0, 0, 137, 0, 0, 24, 0, 0, 0, 0, 0, 0, 0, 16, 102, 0, 0, 14, 137, 0, 0, 56, 102, 0, 0, 147, 142, 0, 0, 136, 0, 0, 0, 0, 0, 0, 0, 56, 102, 0, 0, 37, 142, 0, 0, 64, 0, 0, 0, 0, 0, 0, 0, 16, 102, 0, 0, 51, 142, 0, 0, 56, 102, 0, 0, 87, 142, 0, 0, 96, 0, 0, 0, 0, 0, 0, 0, 16, 102, 0, 0, 72, 142, 0, 0, 116, 102, 0, 0, �]
HEAPU16: Uint16Array(8388608) [28005, 25459, 0, 0, 26168, 0, 35072, 0, 24, 0, 0, 0, 26128, 0, 35086, 0, 26168, 0, 36499, 0, 136, 0, 0, 0, 26168, 0, 36389, 0, 64, 0, 0, 0, 26128, 0, 36403, 0, 26168, 0, 36439, 0, 96, 0, 0, 0, 26128, 0, 36424, 0, 26228, 0, 36450, 0, 0, 0, 3, 0, 88, 0, 2, 0, 136, 0, 4098, 0, 144, 0, 5122, 0, 26128, 0, 36482, 0, 26128, 0, 36465, 0, 26168, 0, 38100, 0, 168, 0, 0, 0, 26228, 0, 38124, 0, 0, 0, 2, 0, 24, 0, 2, 0, 200, 0, 1026, 0, �]
HEAPU32: Uint32Array(4194304) [1668509029, 0, 26168, 35072, 24, 0, 26128, 35086, 26168, 36499, 136, 0, 26168, 36389, 64, 0, 26128, 36403, 26168, 36439, 96, 0, 26128, 36424, 26228, 36450, 0, 3, 88, 2, 136, 4098, 144, 5122, 26128, 36482, 26128, 36465, 26168, 38100, 168, 0, 26228, 38124, 0, 2, 24, 2, 200, 1026, 26128, 38143, 26168, 38364, 224, 0, 26128, 38373, 26168, 75252, 248, 0, 26128, 75277, 26168, 75296, 232, 0, 26168, 75318, 256, 0, 26168, 75346, 256, 0, 26168, 75371, 256, 0, 26168, 75406, 256, 0, 26168, 75436, 232, 0, 26168, 75459, 232, 0, 26168, 75527, 232, 0, 26128, 75515, 26168, 75548, �]
MODERATOR_EXTRA: {}
MODERATOR_SESSION: {audio: false, video: false, screen: false, data: true, oneway: false, �}
MODERATOR_SESSION_ID: "C64-8682F682-3230-4A4C-A1B6-FC49AD2DFE68"
Pointer_stringify: � Pointer_stringify(ptr,length)
Runtime: {setTempRet0: �, getTempRet0: �, stackSave: �, stackRestore: �, getNativeTypeSize: �, �}
SDL: {defaults: {�}, version: null, surfaces: {�}, canvasPool: Array(0), events: Array(0), �}
UTF8ArrayToString: � UTF8ArrayToString(u8Array,idx)
UTF8ToString: � UTF8ToString(ptr)
abort: � abort(what)
addOnExit: � addOnExit(cb)
addOnInit: � addOnInit(cb)
addOnPostRun: � addOnPostRun(cb)
addOnPreMain: � addOnPreMain(cb)
addOnPreRun: � addOnPreRun(cb)
addRunDependency: � addRunDependency(id)
allocate: � allocate(slab,types,allocator,ptr)
arguments: []
asmGlobalArg: {Math: Math, Int8Array: �, Int16Array: �, Int32Array: �, Uint8Array: �, �}
asmLibraryArg: {abort: �, assert: �, enlargeMemory: �, getTotalMemory: �, abortOnCannotGrowMemory: �, �}
buffer: ArrayBuffer(16777216) {}
c64FsSync: � ()
c64postRun: � ()
c64preRun: � ()
c64startup: � ()
callMain: � callMain(args)
calledRun: true
cancelHighscore: � ()
canvas: canvas#canvas
ccall: � ccallFunc(ident,returnType,argTypes,args,opts)
connection: null
connectionStatus: � (state)
createConnection: � (roomName)
createContext: � C64Module_createContext(canvas,useWebGL,setInC64Module,webGLContextAttributes)
ctx: CanvasRenderingContext2D {canvas: canvas#canvas, globalAlpha: 1, globalCompositeOperation: "source-over", filter: "none", imageSmoothingEnabled: true, �}
cwrap: � cwrap(ident,returnType,argTypes)
dynCall_ii: � UI()
dynCall_iii: � XL()
dynCall_iiii: � kF()
dynCall_iiiii: � LK()
dynCall_iiiiii: � CM()
dynCall_iiiiiii: � nI()
dynCall_iiiiiiii: � FE()
dynCall_v: � eK()
dynCall_vi: � bH()
dynCall_vii: � IH()
dynCall_viii: � zJ()
dynCall_viiii: � hN()
dynCall_viiiii: � wG()
dynCall_viiiiii: � qL()
dynCall_viiiiiii: � RF()
enableNetwork: � (roomName)
error: � (v)
exit: � exit(status,implicit)
getDiskBoxHtml: � ()
getMemory: � getMemory(size)
getProperty: � (name)
getUserMedia: � C64Module_getUserMedia()
getValue: � getValue(ptr,type,noSafe)
handleDiskBoxClick: � (event)
hasFocus: true
helpTimer: null
highscoreTimer: null
intArrayFromString: � intArrayFromString(stringy,dontAddNull,length)
intArrayToString: � intArrayToString(array)
isConnected: false
keyboardListeningElement: div#c64TextInputReceiver
lastFilename: ""
lastSnapshot: ""
lengthBytesUTF8: � lengthBytesUTF8(str)
load: � load(f)
loadFile: � (file, startup)
loadSnapshot: � (fileName, useStorage)
loadSnapshotData: � (snapshotData)
monitorRunDependencies: � (left)
muteState: true
noExitRuntime: true
onFullScreenExit: � (softFullscreen)
openAndUnlockAudioContext: � ()
openHelp: � (lang)
pauseMainLoop: � C64Module_pauseMainLoop()
postRun: []
preRun: []
preloadPlugins: (2) [{�}, {�}]
preloadedAudios: {}
preloadedImages: {}
print: � print(x)
printErr: � printErr(x)
read: � read(url)
readAsync: � readAsync(url,onload,onerror)
registerCallback: � (name, callback)
removeRunDependency: � removeRunDependency(id)
requestAnimationFrame: � C64Module_requestAnimationFrame(func)
requestC64FullScreen: � ()
requestFullScreen: � C64Module_requestFullScreen(lockPointer,resizeCanvas,vrDevice)
requestFullscreen: � C64Module_requestFullscreen(lockPointer,resizeCanvas,vrDevice)
requestValue: � (name)
resetEmulation: � (type)
resumeMainLoop: � C64Module_resumeMainLoop()
run: � run(args)
runPostSets: � nE()
saveSnapshotData: � ()
selectJoystick: � (player1, player2)
setCanvasSize: � C64Module_setCanvasSize(width,height,noUpdates)
setJoystick: � (key, down)
setKey: � (key, down)
setMute: � (mute)
setPause: � (pause)
setProperty: � (name, value)
setStatus: � (text)
setTape: � (cmd)
setValue: � setValue(ptr,value,type,noSafe)
setWindowTitle: � (title)
snapshotStorage: � (save)
stackTrace: � stackTrace()
startSequence: 3
stderr: undefined
stdin: undefined
stdout: undefined
storageFileExists: � ()
stringToAscii: � stringToAscii(str,outPtr)
stringToUTF8: � stringToUTF8(str,outPtr,maxBytesToWrite)
stringToUTF8Array: � stringToUTF8Array(str,outU8Array,outIdx,maxBytesToWrite)
thisProgram: "./this.program"
toggleMute: � ()
totalDependencies: 0
updateDiskBox: � ()
updateLoadSnapshot: � ()
uploadHighscore: � (userName, scoreId, snapName)
useWebGL: 0
writeArrayToMemory: � writeArrayToMemory(array,buffer)
writeAsciiToMemory: � writeAsciiToMemory(str,buffer,dontAddNull)
writeStringToMemory: � writeStringToMemory(string,buffer,dontAddNull)
__GLOBAL__sub_I_temscripten_cpp: � zh()
___cxa_can_catch: � lE()
___cxa_is_pointer_type: � mE()
___errno_location: � OB()
___muldi3: � CE()
___muldsi3: � BE()
___udivdi3: � AE()
___udivmoddi4: � yE()
___uremdi3: � zE()
_bitshift64Lshr: � qE()
_bitshift64Shl: � wE()
_free: � kD()
_i64Add: � pE()
_i64Subtract: � oE()
_js_LoadFile: � Bh()
_js_LoadSnapshot: � Ch()
_js_SaveSnapshot: � Dh()
_js_SaveSnapshotSize: � Eh()
_js_enableNetwork: � Fh()
_js_exitFullscreen: � Gh()
_js_getDiskbox: � Hh()
_js_getDiskboxHtml: � Ih()
_js_getProperty: � Jh()
_js_net_OnMessage: � Kh()
_js_net_OnOpen: � Lh()
_js_registerCallback: � Mh()
_js_removeDevice: � Nh()
_js_requestFullscreen: � Oh()
_js_reset: � Ph()
_js_selectJoystick: � Qh()
_js_setDiskbox: � Rh()
_js_setJoystick: � Sh()
_js_setKey: � Th()
_js_setMute: � Uh()
_js_setPause: � Vh()
_js_setProperty: � Wh()
_js_setTape: � Xh()
_js_snapshotStorage: � Yh()
_llvm_bswap_i16: � DE()
_llvm_bswap_i32: � uE()
_llvm_cttz_i32: � xE()
_main: � rj()
_malloc: � jD()
_memcpy: � rE()
_memmove: � tE()
_memset: � vE()
_pthread_self: � EE()
_sbrk: � sE()
__proto__: Object